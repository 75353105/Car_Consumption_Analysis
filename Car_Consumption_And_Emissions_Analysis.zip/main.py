# biblioteci
from itertools import islice

import pandas as pd
import matplotlib.pyplot as plt
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)

def calcul_capacitate_rezervor(df):
    df['FUEL TANK CAPACITY'] = (df['FUEL CONSUMPTION'] * df['MAXIMUM RANGE']) / 100
    return df

def calcul_pret_plin(df):

    def calcul_pe_inregistrare(rand):

        tip_combustibil = rand['FUEL']
        capacitate = rand['FUEL TANK CAPACITY']

        if tip_combustibil == 'GS':
            return 1.2 * capacitate
        elif tip_combustibil == 'GP':
            return 1.45 * capacitate
        elif tip_combustibil == 'DS':
            return 1.3 * capacitate
        elif tip_combustibil == 'DP':
            return 1.55 * capacitate
        else:
            return 0

    df['FILL COST'] = df.apply(calcul_pe_inregistrare, axis=1)
    return df

# importul fisierului csv/setul de date
df_consum = pd.read_csv("FuelConsumption.csv")
print(df_consum.head(10))

#Liste
#Crearea unei liste care contine producatorii de masini
df_producatori = df_consum['MAKE'].drop_duplicates()
lista_producatori = df_producatori.tolist()
print('Lista producatori:')
for i in range (0,len(lista_producatori), 9):
    print(lista_producatori[i:i+9])

#Lungimea listei
print('Lungimea listei de producatori auto: ', len(lista_producatori))

#Eliminarea producatorului ACURA
lista_producatori.remove('ACURA')
print('Lista dupa eliminarea valorii ACURA:')
for i in range (0,len(lista_producatori), 9):
    print(lista_producatori[i:i+9])

#Eliminarea producatorului de pe pozitia 7
print('lista dupa eliminarea elementului de pe pozitia 7:')
lista_producatori.pop(6)
for i in range (0,len(lista_producatori), 9):
    print(lista_producatori[i:i+9])

#Adaugarea unui noi producator pe pozitia 3
lista_producatori.insert(3, 'SKODA')
print('Lista dupa adaugarea valorii SKODA pe pozitia 3:')
for i in range (0,len(lista_producatori), 9):
    print(lista_producatori[i:i+9])

#Aduagarea producatorului Dacia la final
lista_producatori.append("DACIA")
print('Lista cu producatorul DACIA la final:')
for i in range (0,len(lista_producatori), 9):
    print(lista_producatori[i:i+9])

#Sortarea alfabetica a listei
lista_producatori.sort()
print('Lista dupa ordonarea ei alfabetica:')
for i in range (0,len(lista_producatori), 9):
    print(lista_producatori[i:i+9])

#Pozitia producatorului Hyundai
print('Pozitia producatorului Hyundai:')
print(lista_producatori.index('HYUNDAI'))

#Inversarea listei de producatori de masini
print("Lista inversata:")
lista_producatori.reverse()
for i in range (0,len(lista_producatori), 9):
    print(lista_producatori[i:i+9])
print("\n")

#Dictionare
#Crearea unui dictionar care sa contina categoriile de vehicul
clase_vehciule = df_consum['VEHICLE CLASS'].drop_duplicates().tolist()
dict_clase = {}
i = 1
for clasa in clase_vehciule:
    dict_clase[clasa] = ['Clasa de vehicul cu numarul ' + str(i)]
    i = i+1
print("Dictionarul: ")
keys = iter(dict_clase.keys())
for group in iter(lambda: list(islice(keys,4)), []):
    print({key: dict_clase[key] for key in group})

#Numarul clasei de masini SUBCOMPACT
print("Numarul clasei SUBCOMPACT:")
print(dict_clase.get('SUBCOMPACT'))

#Afisarea claselor de vehicule propriu-zise
print("Clasele:")
print(dict_clase.keys())

#Vizualizarea a 4 corespondente intre cheie si valoare
chei_selectate = ['COMPACT', 'MID-SIZE', 'FULL-SIZE', 'SUV']
perechi = [(cheie, valoare) for cheie, valoare in dict_clase.items() if cheie in chei_selectate]
print("Perechile selectate sunt:")
print(perechi)

#Eliminarea ultimei clase de masina
cheie_eliminata, valoare_eliminata = dict_clase.popitem()
print('Am eliminat: ', cheie_eliminata, "-", valoare_eliminata)
print("Dictionar dupa eliminare:")
keys = iter(dict_clase.keys())
for group in iter(lambda: list(islice(keys,4)), []):
    print({key: dict_clase[key] for key in group})

#Afisarea valorilor
print("Afisam valorile pentru fiecare cheie:")
values = iter(dict_clase.values())
for group in iter(lambda: list(islice(values,4)), []):
    print(group)

#Seturi
#Crearea si afisarea unui set care contine transmisiile (pachetul masinii)

set_transmisii = {'A4', 'AS4', 'A5', 'AS5', 'M5', 'M6'}
print('\n')
print('Setul de pachete ale masinilor:')
print(set_transmisii)

#Adaugarea unuei transmisii noi denumita M7
set_transmisii.add('M7')
print('Dupa adaugare:')
print(set_transmisii)

#Eliminarea transmisiei AS4
set_transmisii.remove('AS4')
print('Dupa eliminare AS4:')
print(set_transmisii)

#Verificam daca transmisia M5 exista in set
if 'M5' in set_transmisii:
    print('Exista pachetul M5 in acest set')

#Operatiuni de unuine, intersectie si diferenta
set_transmisii_2 = {'A3', 'A4', 'A5', 'M3', 'M4', 'M5', 'M6'}
set_uniune = set_transmisii.union(set_transmisii_2)
print('Uniunea:')
print(set_uniune)
set_intersectie = set_transmisii.intersection(set_transmisii_2)
print('Intersectia:')
print(set_intersectie)
set_cele_mai_rare = set_transmisii.difference(set_transmisii_2)
print('Diferenta, raman doar cele mai neutilizate pachete:')
print(set_cele_mai_rare)

#Tupluri
#Crearea unui tuplu care contine tipurile de combustibil si afisarea acestuia
tuplu_tipuri_combustibil = ('benzina standard', 'benzina premiun', 'motorina standard', 'motorina premium')
print('\n')
print('Afisam tuplul:')
print(tuplu_tipuri_combustibil)

#Afisarea pozitiei motorinei standard in tuplu
print('Pozitie motorina standard:')
print(tuplu_tipuri_combustibil.index('motorina standard') + 1)

#Concatenarea a doua tupluri
tuplu_sustenabil = ('electricitate', 'hidrogen', 'combustibil bio')
tuplu_metode_alimentare = tuplu_tipuri_combustibil + tuplu_sustenabil
print('Tuplul concatenat:')
print(tuplu_metode_alimentare)

#inmultirea tuplului
tuplu_multiplicat = tuplu_tipuri_combustibil * 2
print('Tuplu multiplicat:')
print(tuplu_multiplicat)

#inlocuirea valorilor lipsa in cadrul coloanei FUEL
#vom introduce codul GS care inseamna benzina standard

df_consum['FUEL'] = df_consum['FUEL'].replace('UNKNOWN', 'GS')
print(df_consum.head(20))

#Eliminarea coloanei year
df_consum.drop(columns=['YEAR'], inplace=True)
df_consum.to_csv("SetFaraColoanaYear.csv")

#Eliminarea randurilor pe baza marcii unei masini
df_comsum_micsorat = df_consum[df_consum['MAKE'] != 'ACURA']
df_comsum_micsorat = df_comsum_micsorat[df_comsum_micsorat['MAKE'] != 'DAEWOO']
df_comsum_micsorat.to_csv("SetFaraAcuraSiDaewoo.csv")
print("Numar initial inregistrari: " + str(df_consum.shape[0]))
print("Numar final inregistrari: " + str(df_comsum_micsorat.shape[0]))

#Gruparea si agregarea datelor dupa clasa de vehicul, media consumului de combustibil
#si media emisiilor de CO2
df_eficienta_clase_vehicul = df_comsum_micsorat.groupby('VEHICLE CLASS').agg({'FUEL CONSUMPTION': 'mean',
                                                                     'COEMISSIONS ': 'mean'})
df_eficienta_clase_vehicul.to_csv("EficientaPeClase.csv")

#Selecatarea randurilor unde consumul este mai mic de 10
df_masini_eficiente = df_comsum_micsorat[df_comsum_micsorat['FUEL CONSUMPTION'] < 10]
df_masini_eficiente.to_csv('SetMasiniEficiente.csv')

#Sortarea datelor in ordine crescatoare pe baza emisiilor de CO2
df_comsum_micsorat.sort_values(by='COEMISSIONS ', inplace=True)
df_comsum_micsorat.to_csv('ClasamentEmisii.csv')

#Adaugarea unei noi coloane care arata capacitatea rezervorului
print("\n Vedem aparitia noii coloane:")
df_comsum_micsorat = calcul_capacitate_rezervor(df_comsum_micsorat)
print(df_comsum_micsorat.head(10))
print('\n')

#Selectarea masinilor manuale
print("\n Aratam masinille manuale din setul de date")
df_masini_manuale = df_comsum_micsorat.loc[df_comsum_micsorat['TRANSMISSION'].isin(['M5', 'M6'])]
print(df_masini_manuale.head(10))
print('\n')

#Vedem care sunt cele mai poluante 10 masini
cele_mai_poluante = df_comsum_micsorat.iloc[-10:]
df_cele_mai_poluante = cele_mai_poluante.loc[:, ['MODEL', 'COEMISSIONS ']]
print(df_cele_mai_poluante)

#Calcularea costului unui plin de combustibil
df_comsum_micsorat = calcul_pret_plin(df_comsum_micsorat)
df_comsum_micsorat.to_csv("SetCuPretPlin.csv")

#Jonctiuni, aflam care continent produce cele mai nepoluante masini
df_continente = pd.read_csv("Continente.csv")
df_jonctiune = pd.merge(df_comsum_micsorat, df_continente, on='MAKE', how='inner')
media_emisii_continent = df_jonctiune.groupby('CONTINENT')['COEMISSIONS '].mean()
print('\n')
print(media_emisii_continent)

#Ce tara produce cele mai eficiente masini
df_tari = pd.read_csv("Tari.csv")
df_jonctiune_2 = df_comsum_micsorat.join(df_tari.set_index('MAKE'), on='MAKE', how='inner')
media_consum_tari = df_jonctiune_2.groupby('COUNTRY')['FUEL CONSUMPTION'].mean()
print('\n')
print(media_consum_tari)

df_eficienta_clase_vehicul = pd.read_csv("EficientaPeClase.csv", sep=',')

df_eficienta_clase_vehicul.columns = df_eficienta_clase_vehicul.columns.str.strip()

#Grafice
#Grafic care arata ce categorie emite cel mai mare consum
plt.figure(figsize=(10, 6))
plt.bar(df_eficienta_clase_vehicul['VEHICLE CLASS'], df_eficienta_clase_vehicul['FUEL CONSUMPTION'], color='skyblue')
plt.title('Consumul mediu de combustibil pe categorie de vehicul')
plt.xlabel('Categorie de vehicul')
plt.ylabel('Consum mediu de combustibil')
plt.xticks(rotation=45)
plt.show()

#Grafic care arata ce categorie emite cele mai multe emisii
plt.figure(figsize=(10, 6))
plt.barh(df_eficienta_clase_vehicul['VEHICLE CLASS'], df_eficienta_clase_vehicul['COEMISSIONS'], color='orangered')
plt.title('Cantitatea de emisii produsa de fiecare categorie de vehicul')
plt.xlabel('Categorie de vehicul')
plt.ylabel('Numarul de emisii')
plt.xticks(rotation=45)
plt.show()
